# 厦门工学院本科毕业论文（设计）LaTeX 模板
## Overleaf 代码教学与使用手册（新手版）

> 适用对象：第一次使用 LaTeX、主要在 Overleaf 上完成本科毕业论文的同学。  
> 适用模板：厦门工学院本科毕业论文 LaTeX 模板“新手批注版”和“AI 示例论文版”。  
> 推荐编译器：XeLaTeX；参考文献后端：Biber。

---

## 1. 先理解：你真正需要修改哪些文件

这套模板把“论文内容”和“论文格式”分开管理。

### 1.1 普通学生主要修改

- `main.tex`：填写论文题目、姓名、学号、专业、年级、指导教师、日期、关键词，并控制全文章节顺序。
- `chap/abstract.tex`：中文摘要和英文摘要。
- `chap/chapter1.tex` ~ `chap/chapter5.tex`：正文各章。
- `chap/conclusion.tex`：总结。
- `chap/acknowledgements.tex`：谢辞。
- `chap/appendixA.tex`、`chap/appendixB.tex`：附录。
- `ref.bib`：参考文献数据库。
- `figures/`：论文中的图片、流程图、实验图、照片等。

### 1.2 普通学生一般不要修改

- `xitthesis.cls`：负责页边距、字体、封面、页眉页脚、目录、标题字号、摘要样式、参考文献标题、附录编号等。

如果只是写论文内容，不需要理解 `xitthesis.cls` 的全部实现。只有模板维护者需要修改这个文件。

---

## 2. 在 Overleaf 上开始使用

### 2.1 上传项目

1. 登录 Overleaf。
2. 选择 **New Project -> Upload Project**。
3. 直接上传模板 ZIP 文件。
4. 等待 Overleaf 自动解压。
5. 确认项目根目录中能看到 `main.tex`、`xitthesis.cls`、`ref.bib`、`chap/`、`figures/`。

不要只上传 `main.tex`。模板依赖 `xitthesis.cls`、章节文件和图片目录。

### 2.2 设置编译器

在 Overleaf 中进入：

**Menu -> Settings -> Compiler -> XeLaTeX**

这套模板不要使用 pdfLaTeX。中文字体、`xeCJK` 和 `ctex` 排版都依赖 XeLaTeX。

### 2.3 参考文献为什么需要多次编译

完整编译逻辑是：

```bash
xelatex main.tex
biber main
xelatex main.tex
xelatex main.tex
```

在 Overleaf 中一般点击 **Recompile** 即可，平台会自动调用 Biber。如果出现目录页码、引用编号或参考文献没有刷新，可以再连续编译 2~3 次。

---

## 3. 项目目录结构

```text
main.tex                         主文件
xitthesis.cls                    模板样式文件
ref.bib                          参考文献数据库
Makefile                         本地命令行编译辅助文件
README.md                        模板说明
chap/
  abstract.tex                   中英文摘要
  chapter1.tex                   第 1 章
  chapter2.tex                   第 2 章
  chapter3.tex                   第 3 章
  chapter4.tex                   第 4 章
  chapter5.tex                   第 5 章
  conclusion.tex                 总结
  acknowledgements.tex           谢辞
  appendixA.tex                  附录一
  appendixB.tex                  附录二
figures/
  logo.png                       封面学校标识
  ...                            论文图片
preview.pdf                      模板预览
```

建议保持这个结构。图片统一放 `figures/`，章节统一放 `chap/`，后期维护会简单很多。

---

## 4. `main.tex` 是整篇论文的总入口

### 4.1 文档类

```tex
\documentclass{xitthesis}
```

这行表示使用本项目中的 `xitthesis.cls` 作为论文样式。封面、目录、标题、页眉页脚等格式都由它决定。

### 4.2 参考文献配置

```tex
\usepackage[backend=biber,style=gb7714-2015,gbnamefmt=lowercase]{biblatex}
\addbibresource{ref.bib}
```

含义：

- `backend=biber`：参考文献由 Biber 处理。
- `style=gb7714-2015`：使用 GB/T 7714-2015 格式。
- `ref.bib`：文献数据保存的位置。

正文引用时使用：

```tex
已有研究表明……\cite{zhang2025example}。
```

### 4.3 常用扩展包

模板的 `main.tex` 已经加载：

```tex
\usepackage{tikz}
\usetikzlibrary{arrows.meta,positioning,shapes.geometric}
\usepackage{siunitx}
\sisetup{detect-all}
```

`tikz` 可用于绘制流程图和框图；`siunitx` 用于规范书写数字与单位。

---

## 5. 修改封面信息

在 `main.tex` 中找到论文基本信息：

```tex
\XITSchool{厦门工学院}
\XITThesisName{本科毕业论文（设计）}
\XITTitle{请输入中文论文题目}
\XITEnglishTitle{Please Input English Thesis Title}
\XITAuthor{请输入姓名}
\XITStudentID{请输入学号}
\XITMajor{请输入专业}
\XITGrade{请输入年级}
\XITSupervisor{请输入指导教师}
\XITDate{请输入日期}
\XITChineseKeywords{关键词一；关键词二；关键词三}
\XITEnglishKeywords{keyword one; keyword two; keyword three}
```

你只需要修改 `{...}` 里面的内容。

例如：

```tex
\XITTitle{基于 STM32 的智能照明系统设计}
\XITEnglishTitle{Design of an STM32-Based Intelligent Lighting System}
\XITAuthor{张明远}
\XITStudentID{2022110001}
\XITMajor{电子信息工程}
\XITGrade{2022 级}
\XITSupervisor{李华}
\XITDate{2026 年 5 月}
```

### 5.1 当前封面字体规则

本版不再把封面所有字段机械地设成同一字号，而是按参考论文的实际 PDF 重新分层：

- `本科毕业论文（设计）`：宋体一号（约 26 pt），常规字重。
- 左侧“题目、姓名、学号、专业、年级、指导教师”：宋体三号（约 16 pt），常规字重。
- 右侧论文题目：黑体三号（约 16 pt），使用黑体常规字形，不额外 `\bfseries`。
- 右侧姓名、学号、专业、年级、指导教师：宋体四号（约 14 pt），常规字重。
- 日期：宋体三号（约 16 pt），常规字重。

这样处理的原因是参考论文封面本身就存在“题目略突出、其他填写值稍小”的层级，并不是所有内容都加粗。Overleaf 预览中黑体会天然比宋体显得更重，但模板不会再额外叠加粗体。

### 5.2 题目长度建议

封面题目栏宽度是固定的。为了保持学校旧版封面的纵向节奏，建议中文题目尽量简洁。如果题目特别长，不要通过大量空格、手工换行来“硬调格式”；优先考虑题目本身是否可以精炼。

---

## 6. 封面 Logo

```tex
\XITLogo{figures/logo.png}
```

如果学校更新了 Logo：

1. 将新图片放到 `figures/`。
2. 修改文件路径。

例如：

```tex
\XITLogo{figures/xit-logo.pdf}
```

XeLaTeX 可直接使用 PDF、PNG、JPG 等常见图片格式。Logo 建议使用清晰的 PNG 或矢量 PDF。

---

## 7. 论文前置部分与正文结构

在 `main.tex` 中：

```tex
\pagenumbering{gobble}
\makecover
\makestatement
```

用于生成封面和声明页，并隐藏页码。

之后：

```tex
\XITFrontMatter
\input{chap/abstract}
\tableofcontents
\clearpage
```

进入前置部分，页码使用罗马数字 I、II、III……

正文：

```tex
\XITMainMatter
\include{chap/chapter1}
\include{chap/chapter2}
\include{chap/chapter3}
\include{chap/chapter4}
\include{chap/chapter5}
\include{chap/conclusion}
```

正文页码切换为阿拉伯数字，从 1 开始。

### 7.1 `\include` 和 `\input` 的区别

- `\input{文件}`：像把文件内容直接粘贴进来，不强制分页。
- `\include{文件}`：适合整章，会自动分页，并生成独立辅助文件。

章节推荐使用 `\include`，摘要可使用 `\input`。

---

## 8. 写中英文摘要

打开 `chap/abstract.tex`：

```tex
\begin{cnabstract}
这里填写中文摘要。
\end{cnabstract}

\begin{enabstract}
This is the English abstract.
\end{enabstract}
```

关键词不要在这里重复手工输入，因为它们来自 `main.tex`：

```tex
\XITChineseKeywords{机器视觉；嵌入式系统；目标检测}
\XITEnglishKeywords{machine vision; embedded system; object detection}
```

摘要中通常不建议放图、表和复杂公式，也尽量避免引用文献。

---

## 9. 章节标题怎么写

### 9.1 章

```tex
\chapter{绪论}
```

模板会自动生成“第 1 章 绪论”，不要自己再写“第 1 章”。

错误示例：

```tex
\chapter{第 1 章 绪论}
```

这样可能出现重复编号。

### 9.2 节

```tex
\section{研究背景与意义}
```

自动生成：`1.1 研究背景与意义`。

### 9.3 小节

```tex
\subsection{机器视觉技术研究现状}
```

自动生成：`1.1.1 机器视觉技术研究现状`。

### 9.4 四级标题

```tex
\subsubsection{具体实现方法}
```

当前模板的标题字体层级为：

- 章：黑体小二。
- 节：黑体小三。
- 小节：黑体小三。
- 四级标题：宋体小四。

目录只显示到小节层级，避免目录过于琐碎。

---

## 10. 正文输入基础

### 10.1 新段落

LaTeX 中推荐用一个空行分段：

```tex
这是第一段正文。

这是第二段正文。
```

模板已经设置首行缩进两个中文字符，不需要在段首手工敲空格。

### 10.2 不要用大量空格调整位置

LaTeX 会自动排版。不要写：

```tex
姓名：          张三
```

论文内容中需要对齐时应使用表格、列表、`tabular`、`align` 等环境。

### 10.3 特殊字符

这些字符在 LaTeX 中有特殊含义：

```text
%  _  &  #  $  {  }  \
```

正文如果要显示它们，通常需要转义：

```tex
\%    \_    \&    \#    \$
```

例如：

```tex
模型准确率达到 98\%。
文件名为 model\_best.pt。
```

---

## 11. 插入图片

先把图片放到 `figures/`，例如：

```text
figures/system_architecture.png
```

正文：

```tex
\begin{figure}[htbp]
  \centering
  \includegraphics[width=0.75\textwidth]{figures/system_architecture.png}
  \caption{系统总体架构}
  \label{fig:system-architecture}
\end{figure}
```

正文引用：

```tex
系统总体架构如图~\ref{fig:system-architecture} 所示。
```

### 11.1 `width` 怎么选

常见写法：

```tex
\includegraphics[width=0.5\textwidth]{...}
\includegraphics[width=0.75\textwidth]{...}
\includegraphics[width=\textwidth]{...}
```

从小到大分别是正文宽度的 50%、75%、100%。不要把低分辨率图片强行放得很大。

### 11.2 `\label` 放在哪里

图片的 `\label` 建议紧跟 `\caption`：

```tex
\caption{系统流程图}
\label{fig:flow}
```

这样交叉引用更稳定。

---

## 12. 三线表

模板已经加载 `booktabs`，推荐三线表：

```tex
\begin{table}[htbp]
  \centering
  \caption{系统性能测试结果}
  \label{tab:performance}
  \begin{tabular}{ccc}
    \toprule
    指标 & 测试值 & 目标值 \\
    \midrule
    响应时间 & 1.2 s & $\leq 2$ s \\
    准确率 & 98.5\% & $\geq 95\%$ \\
    \bottomrule
  \end{tabular}
\end{table}
```

正文引用：

```tex
测试结果见表~\ref{tab:performance}。
```

### 12.1 列格式

```tex
{ccc}
```

表示 3 列，全部居中。

常见列类型：

- `l`：左对齐。
- `c`：居中。
- `r`：右对齐。
- `p{35mm}`：固定宽度 35 mm，并允许自动换行。

例如：

```tex
\begin{tabular}{cp{70mm}c}
```

适合第二列文字较多的表格。

---

## 13. 数学公式

### 13.1 行内公式

```tex
当阈值 $T=0.5$ 时，系统开始执行检测。
```

### 13.2 独立编号公式

```tex
\begin{equation}
  E = mc^2
  \label{eq:energy}
\end{equation}
```

引用：

```tex
由式~\eqref{eq:energy} 可知……
```

### 13.3 多行公式

```tex
\begin{align}
  x &= a+b, \\
  y &= c+d.
\end{align}
```

如果不希望编号，使用：

```tex
\begin{align*}
...
\end{align*}
```

---

## 14. 数字和单位：推荐 `siunitx`

不要手工写大量“数字 + 空格 + 单位”。推荐：

```tex
\SI{3.3}{V}
\SI{10}{mm}
\SI{25}{\degreeCelsius}
\SI{30}{\hertz}
```

例如：

```tex
系统供电电压为 \SI{3.3}{V}，最大定位误差为 \SI{5}{mm}。
```

这样数字和单位的间距会更规范。

---

## 15. 列表

### 15.1 有序列表

```tex
\begin{enumerate}
  \item 完成硬件初始化。
  \item 读取传感器数据。
  \item 执行控制算法。
\end{enumerate}
```

模板已经对一级列表编号格式进行了中文论文风格配置。

### 15.2 无序列表

```tex
\begin{itemize}
  \item STM32 主控模块；
  \item 传感器模块；
  \item 通信模块。
\end{itemize}
```

学术论文中列表不要使用过多，能用连贯文字说明时优先使用正文。

---

## 16. 交叉引用：图、表、章节、公式不要手工写编号

### 16.1 章节

```tex
\section{系统总体设计}
\label{sec:system-design}
```

引用：

```tex
第~\ref{sec:system-design} 节介绍系统总体设计。
```

### 16.2 图片

```tex
\label{fig:architecture}
```

引用：

```tex
如图~\ref{fig:architecture} 所示。
```

### 16.3 表格

```tex
\label{tab:test-result}
```

引用：

```tex
见表~\ref{tab:test-result}。
```

### 16.4 公式

```tex
\label{eq:loss}
```

引用：

```tex
由式~\eqref{eq:loss} 可知。
```

不要手工写“图 3-2”“表 4-1”。章节调整后，LaTeX 会自动更新编号。

---

## 17. 参考文献：`ref.bib` 教学

### 17.1 文献键

每条文献都有一个唯一键，例如：

```bibtex
@article{zhang2025vision,
  ...
}
```

其中 `zhang2025vision` 就是文献键。

正文：

```tex
目标检测算法已广泛应用于工业视觉领域\cite{zhang2025vision}。
```

### 17.2 期刊论文

```bibtex
@article{zhang2025vision,
  author  = {张三 and 李四},
  title   = {基于深度学习的目标检测方法研究},
  journal = {计算机工程},
  year    = {2025},
  volume  = {51},
  number  = {6},
  pages   = {100-108}
}
```

### 17.3 专著

```bibtex
@book{wang2024embedded,
  author    = {王五},
  title     = {嵌入式系统设计基础},
  publisher = {电子工业出版社},
  address   = {北京},
  year      = {2024}
}
```

### 17.4 学位论文

```bibtex
@thesis{li2024thesis,
  author      = {李明},
  title       = {智能机器人视觉系统研究},
  institution = {某某大学},
  year        = {2024},
  type        = {硕士学位论文}
}
```

### 17.5 会议论文

```bibtex
@inproceedings{chen2025conference,
  author    = {Chen, Ming and Wang, Lei},
  title     = {Embedded Vision System Design},
  booktitle = {Proceedings of the International Conference on Embedded Systems},
  year      = {2025},
  pages     = {120-126}
}
```

### 17.6 在线资料

```bibtex
@online{stm32web,
  author  = {{STMicroelectronics}},
  title   = {STM32 Microcontrollers},
  url     = {https://www.st.com/},
  urldate = {2026-05-10},
  year    = {2026}
}
```

正式提交前应按照学校要求核查在线资料是否允许作为主要文献来源。

---

## 18. 代码块

模板已配置 `listings`。例如 Python：

```tex
\begin{lstlisting}[
  language=Python,
  caption={图像处理程序示例},
  label={code:image-process}
]
def process_image(image):
    result = image.copy()
    return result
\end{lstlisting}
```

正文引用：

```tex
核心处理流程见代码~\ref{code:image-process}。
```

C 语言：

```tex
\begin{lstlisting}[language=C,caption={STM32 主循环示例}]
int main(void)
{
    while (1)
    {
        sensor_update();
        control_update();
    }
}
\end{lstlisting}
```

如果代码很长，建议放入附录，而不是正文连续放几十页源码。

---

## 19. 总结、谢辞、附录

### 19.1 总结

`chap/conclusion.tex`：

```tex
\XITConclusion
这里填写总结内容。
```

它会生成不编号的“总结”，并自动加入目录。

### 19.2 谢辞

`chap/acknowledgements.tex`：

```tex
\XITAcknowledgement
这里填写谢辞内容。
```

### 19.3 附录

```tex
\XITAppendix{部分关键源码及解释}
```

模板会生成“附录一 部分关键源码及解释”。

如果没有附录，在 `main.tex` 中注释：

```tex
% \include{chap/appendixA}
% \include{chap/appendixB}
```

---

## 20. 字体系统：怎样在 Overleaf 尽量复现参考论文

模板在 `xitthesis.cls` 中使用 `fontset=none` 并自行指定字体。对第三份参考 PDF 的嵌入字体检查显示，其核心字体是 **SimSun（宋体）/ SimHei（黑体）/ Times New Roman**。因此本版采用三级字体优先级。

### 20.1 Overleaf 上传原版字体（最接近参考论文）

若项目根目录存在以下文件，模板会自动进入“精确字体模式”，无需再改 `xitthesis.cls`：

```text
fonts/simsun.ttc
fonts/simhei.ttf
fonts/times.ttf
fonts/timesbd.ttf
fonts/timesi.ttf
fonts/timesbi.ttf
```

可选文件：

```text
fonts/simfang.ttf
fonts/simkai.ttf
```

字体对应关系：

- 中文正文、目录、页眉、封面普通字段，以及中文正文中的英文和数字：SimSun。
- 章、节、小节、摘要标题、关键词标签：SimHei，使用常规字重，不叠加伪粗。
- 英文摘要、英文标题和页码：Times New Roman；`Abstract` 与 `Key Words:` 使用其 Bold 字形。
- 仿宋 / 楷体：FangSong / KaiTi；若未上传则用 TeX Live 对应字体回退。

项目中已经附带 `copy_windows_fonts.ps1`，可在你自己的 Windows 电脑上把已安装字体复制进 `fonts/`。请仅在你有权使用这些字体的私有论文项目中使用，不要把微软字体再公开分发。

### 20.2 Windows 本地编译

若未在项目内上传字体，但检测到 `C:/Windows/Fonts/simsun.ttc`，模板会直接调用 Windows 系统中的 SimSun / SimHei / Times New Roman / FangSong / KaiTi。

参考论文中 `STM32`、`YOLOv8n`、数字等会随中文段落使用宋体或黑体，而不是统一切换为 Times New Roman；本版已经按这一点处理。

### 20.3 Overleaf 无原版字体时的可编译回退

如果既没有 `fonts/` 原版字体，也不是 Windows 环境，模板自动使用 TeX Live 自带字体：

- 宋体回退：FandolSong Regular。
- 黑体回退：FandolHei Regular（需要粗体时才使用 FandolHei Bold）。
- Times New Roman 回退：Liberation Serif。
- 等宽备用：Noto Sans Mono。

这种模式可直接在 Overleaf 编译，字号、行距、页边距、标题层级和位置仍按参考 PDF 校准；但字形本身不可能与 SimSun / SimHei 完全相同。正式提交若强调字体一致，建议使用上面的 `fonts/` 精确字体模式。

---

## 21. `xitthesis.cls` 中封面代码怎么理解（维护者阅读）

本版封面参数直接按参考 PDF 的实际比例重新校准。核心思路如下：

```tex
\setlength{\xit@coverlabelwidth}{30.4mm}
\setlength{\xit@coverfieldwidth}{87.3mm}

\newcommand{\xit@coverline}[2]{%
  \noindent
  \xit@coverlabel{#1}% 左侧宋体三号标签
  \underline{\makebox[\xit@coverfieldwidth][c]{%
    {\xitcoverfont\zihao{4}#2}% 右侧普通填写值：宋体四号
  }}%
  \par\vspace{4.9mm}%
}

\newcommand{\xit@covertitleline}[1]{%
  \noindent
  \xit@coverlabel{题\hspace{2em}目：}%
  \underline{\makebox[\xit@coverfieldwidth][c]{%
    {\heiti\mdseries\zihao{3}#1}% 论文题目：黑体三号，非额外粗体
  }}%
  \par\vspace{4.9mm}%
}
```

其中：

- 左侧标签宽度约 30.4 mm；
- 下划线填写区约 87.3 mm；
- 普通填写值使用宋体四号；
- 论文题目使用黑体三号；
- `\mdseries` 表示常规字重，不是 `\bfseries`；
- 字段纵向间距已按参考封面重新校准，不建议再通过手工空格调整。

## 22. 修改模板格式时的安全原则（维护者）

### 22.1 想改页边距

在 `xitthesis.cls` 中搜索：

```tex
\geometry{
  left=22mm,
  right=22mm,
  top=26.75mm,
  bottom=24mm
}
```

不要通过在正文中插入 `\hspace`、`\vspace` 来补偿错误页边距。

### 22.2 想改正文行距

搜索：

```tex
\linespread{1.39}
```

### 22.3 想改标题字号

搜索：

```tex
\ctexset{
  chapter = {...},
  section = {...},
  subsection = {...},
  subsubsection = {...}
}
```

### 22.4 想改目录字体

搜索：

```tex
\cftchapfont
\cftsecfont
\cftsubsecfont
```

### 22.5 想改封面

搜索：

```text
Cover page / 封面格式
```

修改封面时每次只调整一个变量，例如字体、字段宽度或垂直间距，然后重新编译对照，不要一次同时改多个参数。

---

## 23. 常见报错与处理

### 23.1 `File ... not found`

原因通常是图片或章节路径错误。

检查：

```tex
\includegraphics{figures/example.png}
```

是否真的存在对应文件，并注意 Overleaf/Linux 区分大小写：

```text
Example.png != example.png
```

### 23.2 `Undefined control sequence`

通常是命令拼错、缺包或反斜杠写错。

例如：

```tex
\sectoin{标题}
```

应为：

```tex
\section{标题}
```

### 23.3 `Missing $ inserted`

正文直接写 `_` 常会触发这个错误：

```tex
model_best.pt
```

应写：

```tex
model\_best.pt
```

或者在代码环境中书写。

### 23.4 引用显示 `??`

重新编译多次，并确认：

```tex
\label{fig:test}
```

和：

```tex
\ref{fig:test}
```

标签完全一致。

### 23.5 参考文献不出现

检查：

1. `ref.bib` 条目格式是否正确。
2. 正文是否真的用了 `\cite{key}`。
3. 是否使用 XeLaTeX + Biber。
4. 是否重新编译 2~3 次。

临时测试所有文献可使用：

```tex
\nocite{*}
```

正式论文一般不建议保留没有正文引用的文献。

### 23.6 图片跑到下一页

`figure` 是浮动体，LaTeX 会自动寻找合适位置。不要因为图片没有“紧贴代码位置”就大量使用强制换行。

推荐：

```tex
\begin{figure}[htbp]
```

如果一个章节中的图特别多，可以调整图片大小或重新组织正文。

### 23.7 表格超出页面

优先：

1. 精简表格文字。
2. 使用 `p{宽度}` 自动换行。
3. 减少不必要的列。
4. 拆成两个表格。

不要第一时间把字体缩得非常小。

---

## 24. Overleaf 写作建议

### 24.1 一章一个文件

不要把 60 页正文全部写进 `main.tex`。章节拆分后定位错误、多人协作、Git 版本管理都更方便。

### 24.2 图片文件名建议只用英文、数字、短横线

推荐：

```text
system-architecture.png
sensor-test-01.jpg
model-loss.pdf
```

不推荐：

```text
最终版本系统结构图（改2）.png
```

### 24.3 标签命名统一

推荐：

```text
sec:system-design
fig:system-architecture
tab:test-result
eq:loss-function
code:main-loop
```

### 24.4 不要手工写页码、目录点线、图编号

这些都是模板应该自动完成的事情。

---

## 25. AI 示例论文版应该怎么用

AI 示例论文版的主要作用是展示“一篇完整论文如何套进模板”。使用时建议：

1. 先复制一份项目，不要直接在原示例上覆盖。
2. 修改 `main.tex` 的全部个人信息和关键词。
3. 从 `chap/chapter1.tex` 开始逐章替换正文。
4. 替换 `figures/` 中示例图片并同步修改文件名。
5. 清空 `ref.bib` 中不属于自己论文的示例文献。
6. 检查所有 `\cite`、`\ref`、`\label` 是否仍然有效。
7. 最后检查目录、摘要、参考文献、附录是否与自己的论文实际内容一致。

不要只替换正文文本而保留与自己课题无关的图、数据、参考文献或结论。

---

## 26. 最终提交前检查清单

- [ ] Overleaf Compiler 已选择 XeLaTeX。
- [ ] 封面题目、姓名、学号、专业、年级、指导教师、日期全部正确。
- [ ] 封面题目为黑体三号，姓名/学号/专业/年级/指导教师为宋体四号，且均未额外加粗。
- [ ] 中文题目和英文题目一致。
- [ ] 中文摘要与英文摘要已替换占位内容。
- [ ] 关键词数量和内容正确。
- [ ] 目录从第 1 章开始，层级正常。
- [ ] 正文无“这里填写……”等模板提示。
- [ ] 所有图片清晰，图题、编号和正文引用一致。
- [ ] 所有表格没有越界。
- [ ] 公式编号和引用正确。
- [ ] 正文引用的文献全部出现在参考文献中。
- [ ] 参考文献中没有未使用的示例条目。
- [ ] 总结、谢辞、附录内容正确。
- [ ] PDF 中没有 `??`、空白引用、缺失图片或字体报错。
- [ ] 如果学校严格检查 Microsoft 宋体，可在 Windows + XeLaTeX 再生成一次最终 PDF；若直接提交 Overleaf PDF，则应明确其使用开源兼容字体。

---

## 27. 推荐的新手学习顺序

不要一次学习整个 LaTeX。按下面顺序最有效：

1. 会在 Overleaf 上传项目和选择 XeLaTeX。
2. 会修改 `main.tex` 的封面信息。
3. 会使用 `\chapter`、`\section`、`\subsection`。
4. 会输入正文和分段。
5. 会插入图片并使用 `\label` / `\ref`。
6. 会制作三线表。
7. 会写公式并使用 `\eqref`。
8. 会在 `ref.bib` 添加文献并用 `\cite` 引用。
9. 会使用代码环境、附录。
10. 最后再了解 `xitthesis.cls` 的字体、封面和目录实现。

对于普通毕业论文写作，掌握以上内容已经足够完成绝大部分排版工作。

---

## 28. 一份最小章节示例

下面这段代码综合展示标题、正文、引用图片、表格、公式和文献：

```tex
\chapter{系统总体设计}

\section{系统架构}
系统由感知层、控制层与执行层组成。整体结构如图~\ref{fig:architecture} 所示。

\begin{figure}[htbp]
  \centering
  \includegraphics[width=0.8\textwidth]{figures/system-architecture.png}
  \caption{系统总体架构}
  \label{fig:architecture}
\end{figure}

\section{性能指标}
系统主要性能指标见表~\ref{tab:requirement}。

\begin{table}[htbp]
  \centering
  \caption{系统性能指标}
  \label{tab:requirement}
  \begin{tabular}{ccc}
    \toprule
    指标 & 目标值 & 备注 \\
    \midrule
    响应时间 & $\leq 2$ s & 正常工作状态 \\
    识别准确率 & $\geq 95\%$ & 测试集统计 \\
    \bottomrule
  \end{tabular}
\end{table}

\section{评价模型}
评价函数定义为
\begin{equation}
  J = \alpha E + \beta T,
  \label{eq:evaluation}
\end{equation}
其中 $E$ 表示能耗，$T$ 表示响应时间。由式~\eqref{eq:evaluation} 可知，系统需要在能耗与响应速度之间进行权衡。相关方法可参考已有研究\cite{sample-reference}。
```

把这一套写法掌握后，就可以直接扩展到完整毕业论文。

---

**手册定位：**模板负责格式，学生负责内容。除非学校发布新的官方排版要求，否则写作过程中应尽量只改 `main.tex`、`chap/*.tex`、`ref.bib` 和 `figures/`，避免因为随意修改 `xitthesis.cls` 导致整篇论文格式漂移。

---

## 29. 毕业论文最常用命令速查表

下面这些命令覆盖本科毕业论文中最常见的排版任务。建议先掌握这些，再学习更复杂的宏包。

| 任务 | 常用代码 | 说明 |
|---|---|---|
| 章标题 | `\chapter{绪论}` | 自动生成“第 1 章” |
| 节标题 | `\section{研究背景}` | 自动编号为 1.1 |
| 小节标题 | `\subsection{系统架构}` | 自动编号为 1.1.1 |
| 图片 | `\includegraphics{...}` | 放在 `figure` 环境中 |
| 表格 | `\begin{tabular}...` | 论文推荐三线表 |
| 公式 | `\begin{equation}...` | 自动编号 |
| 文献引用 | `\cite{key}` | 与 `ref.bib` 配合 |
| 图表引用 | `\ref{label}` | 不要手工写编号 |
| 公式引用 | `\eqref{label}` | 自动带括号 |
| 百分号 | `\%` | `%` 本身是注释符 |
| 下划线 | `\_` | `_` 在正文中需转义 |
| 换页 | `\clearpage` | 会先处理浮动图表 |
| 注释 | `% 这是一条注释` | 编译后不会显示 |

---

## 30. 正文中常见的文字强调与技术名词

毕业论文正文通常不应大量使用粗体或彩色文字。必要的强调可以使用：

```tex
这是普通正文。

\textbf{这是加粗文字。}

\emph{这是强调文字。}

\texttt{main.tex} 是主文件。
```

其中：

- `\textbf{}`：粗体，建议少量使用；
- `\emph{}`：语义强调，英文环境通常表现为斜体；
- `\texttt{}`：等宽字体，适合文件名、函数名、命令名；
- 不建议在正文中随意使用 `\fontsize`、`\zihao` 改字号，论文格式应交给模板统一控制。

### 30.1 LaTeX 注释

```tex
% 这一行不会出现在最终 PDF 中
系统采用 STM32F103 作为主控制器。 % 这里也可以写注释
```

`%` 后面的内容不会输出。新手排查代码时，可以临时把某行前面加 `%` 来判断报错来源。

---

## 31. 两张图片并排：论文中非常常见

模板已经加载 `subcaption`，可以直接使用子图。

```tex
\begin{figure}[htbp]
  \centering
  \begin{subfigure}[b]{0.46\textwidth}
    \centering
    \includegraphics[width=\textwidth]{figures/hardware-front.png}
    \caption{硬件正面}
    \label{fig:hardware-front}
  \end{subfigure}
  \hfill
  \begin{subfigure}[b]{0.46\textwidth}
    \centering
    \includegraphics[width=\textwidth]{figures/hardware-back.png}
    \caption{硬件背面}
    \label{fig:hardware-back}
  \end{subfigure}
  \caption{系统硬件实物图}
  \label{fig:hardware}
\end{figure}
```

引用整张组合图：

```tex
系统硬件如图~\ref{fig:hardware} 所示。
```

引用某一张子图：

```tex
控制器位置见图~\ref{fig:hardware-front}。
```

建议两个子图宽度之和控制在 `0.9\textwidth` 左右，为中间空隙留出空间。

---

## 32. 表格进阶：自动换行、合并列、合并行

### 32.1 固定宽度自动换行

当某一列文字很多时，不要让表格越过页边界，可以写：

```tex
\begin{table}[htbp]
  \centering
  \caption{系统模块功能说明}
  \label{tab:module-description}
  \begin{tabular}{cp{75mm}c}
    \toprule
    模块 & 功能说明 & 接口 \\
    \midrule
    感知模块 & 采集环境数据，并完成滤波、异常值剔除与状态判断。 & I2C \\
    控制模块 & 根据控制策略生成执行器控制指令。 & GPIO \\
    \bottomrule
  \end{tabular}
\end{table}
```

### 32.2 合并多列

模板已加载常用表格宏包，可用 `\multicolumn`：

```tex
\multicolumn{2}{c}{实验结果}
```

完整示例：

```tex
\begin{tabular}{cccc}
  \toprule
  序号 & \multicolumn{2}{c}{实验结果} & 备注 \\
  \cmidrule(lr){2-3}
  & 平均值 & 最大值 & \\
  \midrule
  1 & 12.3 & 15.6 & 正常 \\
  \bottomrule
\end{tabular}
```

### 32.3 合并多行

```tex
\multirow{2}{*}{方案 A} & 精度 & 98.2\% \\
                         & 时间 & 1.3 s \\
```

如果表格非常复杂，优先考虑简化信息，而不是不断缩小字体。

---

## 33. 跨页长表格：`longtable`

当表格超过一页时，可使用模板已加载的 `longtable`：

```tex
\begin{longtable}{cp{85mm}c}
  \caption{实验数据汇总}\label{tab:long-data} \\
  \toprule
  序号 & 测试说明 & 结果 \\
  \midrule
  \endfirsthead

  \multicolumn{3}{c}{表~\thetable\ （续）} \\
  \toprule
  序号 & 测试说明 & 结果 \\
  \midrule
  \endhead

  1 & 第一组测试说明 & 通过 \\
  2 & 第二组测试说明 & 通过 \\
  % 后续继续添加数据
  \\
  \bottomrule
\end{longtable}
```

`longtable` 不需要再放进 `table` 环境，否则容易出现浮动或分页问题。

---

## 34. 公式进阶：分段函数、矩阵、求和与上下标

### 34.1 分段函数

```tex
\begin{equation}
  f(x)=
  \begin{cases}
    0, & x < T, \\
    1, & x \geq T.
  \end{cases}
  \label{eq:threshold}
\end{equation}
```

### 34.2 矩阵

```tex
\begin{equation}
  \mathbf{A}=
  \begin{bmatrix}
    1 & 0 & 0 \\
    0 & 1 & 0 \\
    0 & 0 & 1
  \end{bmatrix}.
\end{equation}
```

### 34.3 求和、上下标

```tex
\begin{equation}
  E_{\mathrm{total}} = \sum_{i=1}^{N} P_i t_i.
\end{equation}
```

常用符号：

```tex
\alpha \beta \gamma \Delta \lambda \mu \sigma \omega
\leq \geq \neq \approx \times \cdot \pm
```

不要直接从 Word 复制复杂公式到源码中。建议用 LaTeX 数学语法重新录入。

---

## 35. 多篇文献同时引用

正文可以一次引用多篇文献：

```tex
已有研究从机器视觉、嵌入式控制和边缘计算等角度进行了探索\cite{refA,refB,refC}。
```

如果模板使用 GB/T 7714-2015 数字顺序制，最终会自动生成类似：

```text
……进行了探索[1-3]。
```

不要手工输入 `[1]`、`[2]`，否则章节和文献顺序发生变化后编号不会自动更新。

---

## 36. 引用网页、网址与 DOI

正文中需要直接显示网址时，可以使用：

```tex
\url{https://www.example.com/}
```

更推荐把网页作为参考文献加入 `ref.bib`，然后正文使用 `\cite{}`，例如：

```bibtex
@online{stm32datasheet,
  author  = {{STMicroelectronics}},
  title   = {STM32F103 Product Page},
  url     = {https://www.st.com/},
  urldate = {2026-05-10},
  year    = {2026}
}
```

正式论文中，数据手册、标准、学术论文应优先于博客或普通网页。

---

## 37. 从外部文件插入程序代码

如果代码已经保存在文件中，不必复制粘贴到 `.tex`：

```tex
\lstinputlisting[
  language=C,
  caption={主控制程序},
  label={code:main-c}
]{code/main.c}
```

Python：

```tex
\lstinputlisting[
  language=Python,
  caption={数据处理程序},
  label={code:data-process}
]{code/data_process.py}
```

建议额外建立：

```text
code/
  main.c
  data_process.py
```

这样源码与论文排版代码相互独立，维护更方便。

---

## 38. 换行、换页和浮动体：什么时候应该用什么

### 38.1 正常分段

最推荐：源码中空一行。

```tex
第一段。

第二段。
```

### 38.2 强制换行

```tex
第一行\\
第二行
```

正文里不要频繁使用 `\\` 代替分段。

### 38.3 普通换页

```tex
\newpage
```

### 38.4 处理完图片和表格再换页

```tex
\clearpage
```

毕业论文中章节切换、目录结束、附录切换等场景更常用 `\clearpage`，因为它会先输出尚未排版的浮动图表。

---

## 39. 图片为什么“不在代码所在位置”

`figure` 和 `table` 默认属于浮动体。参数：

```tex
[htbp]
```

含义：

- `h`：here，优先当前位置；
- `t`：top，页顶；
- `b`：bottom，页底；
- `p`：单独浮动页。

LaTeX 会根据页面剩余空间自动选择位置。论文排版中，不建议为了“图片必须紧贴某一句话”而大量强制定位。

如果图片总是跑得很远，优先检查：

1. 图片是否过大；
2. 前面是否连续堆放了很多浮动体；
3. 当前页是否已经没有足够空间；
4. 正文是否过少。

---

## 40. `~` 的作用：让“图 2-1”不要被拆开

推荐：

```tex
如图~\ref{fig:system} 所示。
见表~\ref{tab:test}。
由式~\eqref{eq:model} 可知。
```

这里的 `~` 是不可断行空格，可避免“图”留在一行末尾、编号跑到下一行。

---

## 41. 常见英文缩写第一次出现时怎么写

学术论文中常见写法：

```tex
卷积神经网络（Convolutional Neural Network，CNN）能够提取图像特征。
```

后文直接写：

```tex
CNN 的输入尺寸设置为 $320\times320$。
```

不要为了英文缩写单独修改字体。模板已经统一处理中英文和数字的字体族。

---

## 42. 一段完整的“实验结果”写法示例

```tex
\section{实验结果与分析}

为验证所设计系统的性能，对响应时间、识别准确率和功耗进行测试。实验平台配置见表~\ref{tab:test-platform}。

\begin{table}[htbp]
  \centering
  \caption{实验平台配置}
  \label{tab:test-platform}
  \begin{tabular}{cc}
    \toprule
    项目 & 配置 \\
    \midrule
    主控制器 & STM32F103 \\
    工作电压 & \SI{3.3}{V} \\
    采样频率 & \SI{10}{\hertz} \\
    \bottomrule
  \end{tabular}
\end{table}

系统平均响应时间定义为
\begin{equation}
  T_{\mathrm{avg}}=\frac{1}{N}\sum_{i=1}^{N}T_i,
  \label{eq:avg-time}
\end{equation}
其中，$N$ 为实验次数，$T_i$ 为第 $i$ 次测试的响应时间。

实验结果如图~\ref{fig:response-time} 所示。由式~\eqref{eq:avg-time} 计算得到系统平均响应时间为 \SI{1.28}{s}，满足设计指标。相关嵌入式控制方法可参考文献\cite{sample-reference}。

\begin{figure}[htbp]
  \centering
  \includegraphics[width=0.72\textwidth]{figures/response-time.png}
  \caption{系统响应时间测试结果}
  \label{fig:response-time}
\end{figure}
```

这个例子同时包含：章节、正文、表格、单位、公式、交叉引用、文献引用和图片，是毕业论文实验章节最典型的组合。

---

## 43. 一个可以直接复制的章节骨架

新建 `chap/chapterX.tex` 时，可以先复制下面的结构：

```tex
\chapter{本章标题}

本章首先……，然后……，最后……。

\section{第一节标题}

这里填写正文。

\subsection{第一小节标题}

这里填写正文。

\section{第二节标题}

这里填写正文，可插入图、表或公式。

\section{本章小结}

本章完成了……，主要包括以下工作：……。
```

注意：是否需要“本章小结”应根据学院、专业和指导教师要求决定，不要机械添加。

---

## 44. 毕业论文中最容易犯的 LaTeX 排版错误

### 44.1 手工编号

错误：

```tex
图 3-2 是系统结构图。
```

正确：

```tex
图~\ref{fig:system} 是系统结构图。
```

### 44.2 用空格做对齐

错误：

```tex
名称        数值        单位
```

正确：使用 `tabular`。

### 44.3 为了让图不移动而连续写很多 `\vspace`

这会导致换页后整个版式失控。应优先使用浮动体机制和合理图片尺寸。

### 44.4 在章节标题里自己写编号

错误：

```tex
\section{2.1 系统需求}
```

正确：

```tex
\section{系统需求}
```

### 44.5 直接在源码中写 `%`

错误：

```tex
准确率为 98%。
```

`%` 后面的内容会被当成注释。应写：

```tex
准确率为 98\%。
```

---

## 45. Overleaf 报错时的推荐排查顺序

遇到红色报错，不要先大范围删除代码。按以下顺序检查：

1. 看 **第一条真正的 Error**，后面的错误可能只是连锁反应；
2. 看错误提示中的文件名和行号；
3. 检查最近修改的 `{}`、`\begin{}` / `\end{}` 是否成对；
4. 检查 `_`、`%`、`&`、`#` 等特殊字符是否忘记转义；
5. 检查图片路径和大小写；
6. 检查 `\cite{}`、`\ref{}` 的键是否拼写一致；
7. 如果参考文献异常，执行 Recompile，多编译几次；
8. 仍无法定位时，用 `%` 临时注释最近新增的一小段代码，逐块排查。

一个很实用的原则是：**每次只修改一小块，并在修改后立即编译**。这样即使报错，也能很快找到来源。

---

## 46. 给模板使用者的最终原则

毕业论文 LaTeX 排版中，最重要的不是“会多少命令”，而是保持自动化：

- 标题让 `\chapter` / `\section` 自动编号；
- 图表让 `\caption` 自动编号；
- 交叉引用让 `\label` / `\ref` 自动更新；
- 文献让 BibLaTeX + Biber 自动排序；
- 字体、字号、页边距、目录和页眉交给 `xitthesis.cls`；
- 学生只负责论文内容，不通过空格、手工字号和大量 `\vspace` 去“修页面”。

这样即使论文后期增加章节、删除图片或调整顺序，整篇文档仍能自动保持一致。
