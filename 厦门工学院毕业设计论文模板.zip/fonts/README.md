# Overleaf 精确字体上传说明

本模板已经按第三份参考 PDF 的实际嵌入字体配置为：**SimSun（宋体）+ SimHei（黑体）+ Times New Roman**。

> 这里不附带微软字体二进制文件。请从你自己有权使用的 Windows 安装中复制到本目录，用于你的私有论文项目；不要把这些字体再次公开分发。

## 1. 建议放入 `fonts/` 的文件

精确匹配所需：

```text
simsun.ttc      宋体 SimSun
simhei.ttf      黑体 SimHei
times.ttf       Times New Roman Regular
timesbd.ttf     Times New Roman Bold
timesi.ttf      Times New Roman Italic
timesbi.ttf     Times New Roman Bold Italic
```

可选：

```text
simfang.ttf     仿宋 FangSong
simkai.ttf      楷体 KaiTi
```

Windows 通常可在 `C:\Windows\Fonts\` 找到这些文件。项目根目录提供了 `copy_windows_fonts.ps1`，可以自动复制已存在的文件。

## 2. Overleaf 使用方法

1. 在 Windows 上运行项目根目录的 `copy_windows_fonts.ps1`，或手工把上述字体复制到本 `fonts/` 目录。
2. 将整个论文项目 ZIP 上传到 Overleaf。
3. Overleaf 菜单中将 Compiler 设为 **XeLaTeX**。
4. 重新编译。日志中若出现 `Using project-local SimSun/SimHei fonts from fonts/`，说明已经进入精确字体模式。

## 3. 没有上传字体时

模板仍可直接编译，会自动使用：

- FandolSong Regular 代替 SimSun；
- FandolHei Regular 代替 SimHei；
- Liberation Serif 代替 Times New Roman。

这种回退模式的字号、行距、页边距和位置仍按参考 PDF 校准，但字形本身不会完全相同。
